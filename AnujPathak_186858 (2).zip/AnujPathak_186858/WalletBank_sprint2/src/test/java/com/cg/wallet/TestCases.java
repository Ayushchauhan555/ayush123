package com.cg.wallet;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;

import org.junit.jupiter.api.Test;
import org.omg.CORBA.UserException;

import com.cg.bean.PayBean;
import com.cg.service.PayService;
class TestCases {
	PayService serv=new PayService();
	PayBean acOpen=new PayBean();
	@Test
	public void testStoreIntoMap() throws UserException {
		
		acOpen.setName("Mayank");
		acOpen.setAddress("Mathura");
		acOpen.setPhnno(9193207896L);
		acOpen.setBalance(5000);
		
		boolean result=serv.create(acOpen);
		
		assertTrue(result);
	}
	@Test
	public void testAddBalance() throws UserException
	{
//		HashMap<Long,PayBean >map = new HashMap<Long, PayBean>();
//		PayBean acOpen = new PayBean();
//		acOpen.setAccno(9193207896L);
//		acOpen.setAddress("Mathura");
//		
//		acOpen.setBalance(5000);
//		acOpen.setPhnno(919320775L);	
//		map.put(1001l, acOpen);
		
		boolean result=serv.deposit(6754321557l,600.000);
		assertTrue(result);
	}
	@Test
	public void testFundTransfer() throws UserException
	{
//		HashMap<Long,PayBean >map = new HashMap<Long, PayBean>();
//		PayBean acOpen = new PayBean();
//		acOpen.setAccno(1001);
//		acOpen.setBalance(5000);
//		acOpen.setPhnno(9803538343L);	
//		map.put(1001l, acOpen);
//		
//		PayBean acOpen2 = new PayBean();
//		acOpen.setAccno(1002);
//		acOpen.setBalance(6000);
//		acOpen.setPhnno(9803768343L);
//		map.put(1002l, acOpen2);
		boolean result=serv.transferFund(6754321557l,8989898868l,600.000);
		assertTrue(result);
	}

	@Test
	public void testWithdrawAmount() throws UserException
	{
//		HashMap<Long,PayBean >map = new HashMap<Long, PayBean>();
//		PayBean acOpen = new PayBean();
//		acOpen.setAccno(9193207896L);
//		acOpen.setAddress("Mathura");
//		
//		acOpen.setBalance(5000);
//		acOpen.setPhnno(919320775L);	
//		map.put(1001l, acOpen);
//		
		boolean result=serv.Withdraw(6754321557l, 600.000);
		assertTrue(result);
	}


}
