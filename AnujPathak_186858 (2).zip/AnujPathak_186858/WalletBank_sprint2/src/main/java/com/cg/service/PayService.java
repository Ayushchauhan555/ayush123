package com.cg.service;

import java.util.Scanner;

import com.cg.bean.PayBean;
import com.cg.dao.PayDao;

public class PayService {
	 PayDao paydao=new PayDao();
	 Scanner sc=new Scanner(System.in);
	
	
public boolean create(PayBean p)
{
	paydao.addUser(p);
	return true;
	
}
public boolean deposit(long accno,double balance)
{
	boolean res=false;
	res = paydao.deposit(accno, balance);
	return res;
		
}
public double display(long accno)
{
	double balance = paydao.display(accno);
	return balance;
	
}

public boolean Withdraw(long accno,double balance)
{
	boolean res = paydao.Withdraw(accno, balance);
	return res;
}

public boolean transferFund(long sourceaccno,long destinationaccno,double transferamount)
{
	boolean r=false;
	r = paydao.transferFund(sourceaccno, destinationaccno, transferamount);
	return r;
}
}

	

	
	
	 
	



