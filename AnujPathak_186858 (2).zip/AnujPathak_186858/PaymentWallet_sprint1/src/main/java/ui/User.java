package ui;

import java.util.Scanner;

import service.PayMod;
import service.PayService;

public class User {
public static void main(String args[])
{
	PayService p=new PayService();
	PayMod pd=new PayMod();
	
	Scanner sc=new Scanner(System.in);
	int choice;
	System.out.println("___________________________________");
	System.out.println("0.Create Account");
	System.out.println("1.Display");
	System.out.println("2.Deposit");
	System.out.println("3.Withdraw");
	System.out.println("4.TransferFund");
	System.out.println("____________________________________");
	
	choice=sc.nextInt();
	while(true)
	{
		
	
   switch(choice)
   {
   case 0:
	   System.out.println("Enter the name");
		String name = pd.Check(sc.next());
		System.out.println("Enter the address");
		String address=sc.next();
		System.out.println("Enter phone number");
		long phnno = pd.mobCheck(sc.nextLong());
		System.out.println("Enter balance");
		double balance =pd.aCheck(sc.nextFloat());
		long accno=phnno-121;
		System.out.println("Successfully!!! Your Account is generated And Your Generated Account number is" +accno);
		
	   p.create(accno, name, address, phnno, balance);
	   
	   break;
   case 1:
	
	System.out.println("Enter Account number");
	 accno=sc.nextLong();
	double ab=p.display(accno);
	if(ab>-1)
	{
		System.out.println("your balnce ="+ab);
	}
	else
	{
		System.out.println("Invalids");
	}
	 break;
	 
   case 2:
		System.out.println("Enter your Account Number");
		 accno=sc.nextLong();
		System.out.println("Enter amount you want deposit");
	    balance=sc.nextDouble();
	   
	boolean res=p.deposit(accno, balance);
	
	if(res)
	{
		System.out.println("Deposit Success");
		
	}
	else
	{
		System.out.println("Invalid");
	}
	break;
	
   case 3:
	   System.out.println("Enter your Account Number");
		 accno=sc.nextLong();
		System.out.println("Enter amount you want Withdraw");
		 balance=sc.nextDouble();
	   
		
		boolean  re = p.Withdraw(accno, balance);
		if(re)
		{
			System.out.println("withdraw  Success");
			
		}
		else
		{
			System.out.println("Invalid");
		}
		break;
	   
   case 4:

	System.out.println("Enter Source Account Number: ");
	long sourceaccno = sc.nextLong();
	System.out.println("Enter Destination Account Number: ");
	long destinationaccno = sc.nextLong();
	System.out.println("Enter Amount to transfer: ");
	double transferamount=sc.nextDouble();
		
	boolean r= p.transferFund(sourceaccno, destinationaccno, transferamount);
	if(r)
	{
		System.out.println("Transfer Successfully");
	}
	else
	{
		System.out.println("invalid");
	}
		
		break;
	   
	}

	System.out.println("0.Create Account");
	System.out.println("1.Display");
	System.out.println("2.Deposit");
	System.out.println("3.Withdraw");
	System.out.println("4.TransferFund");
	choice=sc.nextInt();

}
}
}



