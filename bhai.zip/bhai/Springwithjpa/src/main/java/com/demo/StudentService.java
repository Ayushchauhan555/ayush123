package com.demo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
public class StudentService {


	

		@Autowired
		StudentDao dao;
		
		@Transactional
		public void addEmployee(Student e) {
			dao.addEmployee(e);
		}
		public void deleteEmployee(Student e) {
			dao.deleteEmployee(e);
			
		}
		public void updateEmployee(Student e) {
			dao.updateEmployee(e);
			
		}

}
