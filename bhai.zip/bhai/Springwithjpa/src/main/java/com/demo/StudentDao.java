package com.demo;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;




@Repository
public class StudentDao {


	
	
		@PersistenceContext
		EntityManager em;
		public void addEmployee(Student e) {
			em.persist(e);
		}
		@PersistenceContext
		EntityManager ex;
		EntityManagerFactory ef=null;
		@Transactional
		public void deleteEmployee(Student e) {
		
			Student emp=ex.find(Student.class, 1005);
			
			
			ex.remove(emp);
			
		}
		@Transactional
		public void updateEmployee(Student e) {
		
			Student emp=ex.find(Student.class, 1006);
			
			
			emp.setStudentName("Anju");
			emp.setCity("mathura");
			
		}

}

