
package com.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Starter {
	private static ApplicationContext con;

	public static void main(String[] args) {
		
		Student e = new Student();
//		e.setCity("chenn");
//		e.setStudentId(1006);
//		e.setStudentName("Anu");
//		e.setDept("BA");
		con = new AnnotationConfigApplicationContext(Config.class);
		
		StudentService service = (StudentService)con.getBean("studentService");
		//service.addEmployee(e);
		//service.deleteEmployee(e);
		service.updateEmployee(e);
		System.out.println("rec inserted");
	}
}


