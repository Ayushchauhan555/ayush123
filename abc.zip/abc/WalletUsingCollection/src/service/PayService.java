package service;

import java.util.Scanner;
import bean.PayBean;
import dao.PayDao;

public class PayService {
	 PayDao paydao=new PayDao();
	 Scanner sc=new Scanner(System.in);
	
	
public void create(long accno,String name,String address,long phnno,double balance)
{
	PayBean paybean=new PayBean(accno,name,address,phnno,balance);
	paydao.addUser(paybean);
}
public boolean deposit(long accno,double balance)
{
	boolean res=false;
	res = paydao.deposit(accno, balance);
	return res;
		
}
public double display(long accno)
{
	double balance = paydao.display(accno);
	return balance;
	
}

public boolean Withdraw(long accno,double balance)
{
	boolean res = paydao.Withdraw(accno, balance);
	return res;
}

public boolean transferFund(long sourceaccno,long destinationaccno,double transferamount)
{
	boolean r=false;
	r = paydao.transferFund(sourceaccno, destinationaccno, transferamount);
	return r;
}
}

	

	
	
	 
	



