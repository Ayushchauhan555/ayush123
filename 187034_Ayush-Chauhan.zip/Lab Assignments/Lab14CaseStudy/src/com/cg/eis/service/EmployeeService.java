package com.cg.eis.service;

import java.util.List;

import com.cg.eis.bean.Employee;
import com.cg.eis.dao.EmployeeDao;

public class EmployeeService {
	EmployeeDao empd=new EmployeeDao();
	public String retriveScheme(double salary,String designation) {
		String scheme="";
		if((salary>=20000&&salary<40000)&&designation.equals("Programmer"))
			scheme+="Scheme B";
		if((salary>5000&&salary<20000)&&designation.equals("System Associate"))
			scheme+="Scheme C";
		if((salary>=4000)&&designation.equals("Manager"))
			scheme+="Scheme A";
		if((salary<5000)&&designation.equals("clerk"))
			scheme+="No Scheme";
		
		return scheme;
		
	}
	/*public boolean addEmployee(Employee e) {
		// TODO Auto-generated method stub
		return empd.addEmployee(e);
	}
	/*public List<Employee> getEmployees(){
		return empd.getEmployees();
	}*/
}