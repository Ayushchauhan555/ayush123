package Lab5flowControl;
import com.cg.eis.exception.*;

public class SalaryOfAnEmployee {
	
	public static void main(String args[]) {
		int salary=6700;
		
		// if salary is less than 3000 an exception will be thrown
		try {
			if(salary<3000)
				throw new EmployeeException("Invalid Salary");
			else
				System.out.println(salary);
		}
		catch(EmployeeException e ) {
			System.out.println(" Error Occured ");
		}
	}
}

