package Lab8StringIO;

import java.util.Scanner;

public class PositiveString {
	
	public static void main(String[] args) {
    	Scanner sc=new Scanner(System.in);
    	System.out.println("Enter String name");
        String string = sc.next();
        PositiveString obj = new PositiveString();
        boolean result = obj.checkPositive(string);
        if (result)
            System.out.println(string+" is a positive String"); 
        else 
            System.out.println(string+" is not a positive String"); 
        sc.close();
    } 

	// 
	public boolean checkPositive(String str) { 

        for (int i = 1; i < str.length(); i++) {   
            if (str.charAt(i) < str.charAt(i - 1)) { 
                return false; 
            } 
        } 
  
        return true; 
    } 
}
