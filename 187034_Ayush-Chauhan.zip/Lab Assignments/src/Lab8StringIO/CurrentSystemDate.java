package Lab8StringIO;


import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class CurrentSystemDate {

	public static void main(String[] args)
    {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter year");
		int year = sc.nextInt();
		System.out.println("Enter month");
		int month = sc.nextInt();
		System.out.println("Enter day");
		int day = sc.nextInt();
;       LocalDate pdate = LocalDate.of(year, month, day);
        LocalDate now = LocalDate.now();
 
        Period diff = Period.between(pdate, now);
        
        // printing the difference using pre-defined methods
        System.out.println("Difference in years is "+diff.getYears() +" in months is "+diff.getMonths() +" in days is "+diff.getDays());
        sc.close();
  }

}
