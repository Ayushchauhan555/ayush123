package Lab11concurrent;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class lab11 {
public static void main(String[] args) {
	System.out.println("Inside :"+Thread.currentThread().getName());
	
	System.out.println("Creating Executor service...");
	ExecutorService execotorService=Executors.newSingleThreadExecutor(); 
	
	System.out.println("Creating a Runnable...");
	Runnable runnable=()->{
		System.out.println("Inside :"+Thread.currentThread().getName());
	};
	System.out.println("submit the task specified by the runnable to the executor");
	execotorService.submit(runnable);
	execotorService.submit(runnable);
	execotorService.submit(runnable);
	
}
}