package Lab13Labdaexpressions;

import java.util.Scanner;
import java.util.function.BiFunction;

public class Lab13Exercise3 {

	public static void main(String[] args) 
		// TODO Auto-generated method stub
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the username: ");
		String uname=sc.next();
		System.out.println("Enter the password: ");
		String pass=sc.next();
		BiFunction<String, String, Boolean>check=(uname1,pass1)->uname1.equals("Capgemini")&& pass1.equals("Hello");
		boolean res=check.apply(uname,pass);
		if(res)
			System.out.println("Welcome.....");
		else
			System.out.println("Incorrect credentials.....");		
	}

}