package Lab13Labdaexpressions;

import java.util.*;
import java.lang.*;

interface Power
{
	public double numpower(double a,double b);
	}

public class Lab13Exercise1 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
	    System.out.println("Please Enter the Base Number: ");
		double a =sc.nextFloat();
		System.out.println("Please Enter the Exponential Number: ");
		double b =sc.nextFloat();
		Power p=(x,y) ->Math.pow(a,b);
		double power =p.numpower(a,b);
		System.out.println(power);
		
	}

}
