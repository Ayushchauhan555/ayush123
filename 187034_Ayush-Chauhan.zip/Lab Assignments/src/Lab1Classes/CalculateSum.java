package Lab1Classes;

import java.util.Scanner;

public class CalculateSum {
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value of number");
		int number=sc.nextInt();
		CalculateSum obj = new CalculateSum();
		obj.calculateSum(number);
		sc.close();
	}
	//method to calculate sum of n numbers that are divisible by 3 or 5
	public void calculateSum(int n){
		int sum=0;
		for(int counter=1; counter<=n ;counter++){
			if(counter%3==0 || counter%5==0){
				sum=sum+counter;
			}	
		}
		System.out.println("Sum of first "+n+" natural numbers is "+sum);
	}
}
