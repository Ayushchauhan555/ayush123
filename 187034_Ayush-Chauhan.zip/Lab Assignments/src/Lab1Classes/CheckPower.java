package Lab1Classes;

import java.util.Scanner;

public class CheckPower {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value of number");
		int number=sc.nextInt();
		CheckPower obj = new CheckPower();
		boolean result = obj.checkNumber(number);
		if(result==true)
			System.out.println(number+" is a power of 2");
		else
			System.out.println(number+" is not a power of 2");
		sc.close();
	}
	
	// check if the given number is a power of 2
	public boolean checkNumber(int number){
		while(number!=1){
			if(number%2!=0)
				return false;
			number=number/2;
		}
		return true;
	}
}
