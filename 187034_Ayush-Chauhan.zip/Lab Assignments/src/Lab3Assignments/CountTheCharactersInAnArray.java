package Lab3Assignments;

import java.util.Arrays;
import java.util.Scanner;

public class CountTheCharactersInAnArray {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		char array[] = new char[size];
		for(int i=0; i<size; i++)
			array[i] = sc.next().charAt(0);
		CountTheCharactersInAnArray obj = new CountTheCharactersInAnArray();
		obj.characterCount(array);
		sc.close();
	}
	
	void characterCount(char array[]) {
		int length=array.length;
		int counter=0;
		Arrays.sort(array);
		for(int i=0; i<length; i+=counter) {
			if(i>=length)
				System.exit(0);
			counter=0;
			char character=array[i];
			for(int j=0; j<length; j++) {
					if(character==array[j])
						counter++;
			}
			System.out.println(array[i]+" comes "+counter+" times.");
		} 
	}
}


